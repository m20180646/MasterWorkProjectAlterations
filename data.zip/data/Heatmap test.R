library(shiny)
library(RColorBrewer)
library(heatmaply)

# a linha que tem os nomes para as variaveis do heatmap
row.names(heat_cca_n) <- heat_cca_n$NAME 

# selecionar as linhas de dados que v�o ser necess�rias para o heatmap (dataset)
heat_cca_n<- heat_cca_n[,2:13]    

# � necess�rio transpor o dataset para usar no heatmap
heat_cca_n <-  t(heat_cca_n) 

# � necess�rio transformar o dataset em matriz para usar no heatmap
heat_cca_n_matrix <- as.matrix(heat_cca_n) 
head(heat_cca_n)   

#palete de cores para o heatmap
colourPalette <- brewer.pal(5,'YlOrRd')

# um heatmap simples sem clusters nem interatividade
#month_by_year_heatmap <- heatmap(heat_cca_n_matrix,Colv =NA, Rowv = NA, scale = 'none',col = colourPalette,legend= col)

# um heatmap interativo com o pacote plotly mas sem clusters. Em que o x e o y s�o dataset e o z a matriz.
#plot_ly(x=colnames(heat_cca_n), y=rownames(heat_cca_n),z = heat_cca_n_matrix,colors =colourPalette, type = "heatmap")
  
# Usamos o pacote heatmaply (extens�o do pacote plotly) para criar um heatmap interactivo com clusters em que especificamos 2 grupos para as linhas e 2 grupos para as colunas.
heatmaply(heat_cca_n_matrix, k_row = 2, k_col = 2) 

# Sites para mais informa��es:
# https://cran.r-project.org/web/packages/heatmaply/vignettes/heatmaply.html
# https://moderndata.plot.ly/interactive-heat-maps-for-r/

# o excel do heatmap dever� ter o seguinte formato (exemplo):
#  NAME possui os nomes para as vari�veis das linhas e das colunas e depois "dentro" o valor correspondente a combina��o de cada linha com cada coluna. 
# Deve ser um ficheiro excel transformado em csv. 

# NAME;Jan;Feb;Mar;Apr;May;Jun;Jul;Aug;Sep;Oct;Nov;Dec
# 1996;153.281;98.971;67.891;46.431;89.071;318.131;176.161;373.171;2.521;271.161;29.651;292.621
# 1997;581.581;-0.839;69.581;431.681;175.641;208.691;10.031;186.271;76.171;239.971;374.931;225.521